package com.example.tp2exo8;

public class Pays {
    private final String nom;
    private final String capitale;
    private final String langue;
    private final String nbHab;

    public Pays(String nom, String capitale, String langue, String nbHab) {
        this.nom = nom;
        this.capitale = capitale;
        this.langue =langue;
        this.nbHab=nbHab;
    }

    public String getNom() {
        return nom;
    }

    public String getCapitale() {
        return capitale;
    }

    public String getLangue() {
        return langue;
    }

    public String getnbHab() {
        return nbHab;
    }
}
