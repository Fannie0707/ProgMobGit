package com.example.tp2exo8;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    private TextView textViewNom;
    private TextView textViewCapitale;
    private TextView textViewLangue;
    private TextView textViewnbHab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_second);

        textViewNom = findViewById(R.id.textViewNom);
        textViewCapitale = findViewById(R.id.textViewCapitale);
        textViewLangue = findViewById(R.id.textViewLangue);
        textViewnbHab = findViewById(R.id.textViewnbHab);

        String nomPays = getIntent().getStringExtra("p_nom");
        String CapitalePays = getIntent().getStringExtra("p_capitale");
        String LanguePays = getIntent().getStringExtra("p_langue");
        String nbHabPays = getIntent().getStringExtra("p_nbHab");

        textViewNom.setText(nomPays);
        textViewCapitale.setText(CapitalePays);
        textViewLangue.setText(LanguePays);
        textViewnbHab.setText(nbHabPays);
    }
}
