package com.example.tp2exo8;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PaysAdapt extends RecyclerView.Adapter<PaysAdapt.ViewHolder> {

    private final List<Pays> paysList;
    private final OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Pays pays);
    }

    public PaysAdapt(List<Pays> paysList, OnItemClickListener listener) {
        this.paysList = paysList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pays, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pays pays = paysList.get(position);
        holder.textView.setText(pays.getNom());
        holder.itemView.setOnClickListener(v -> listener.onItemClick(pays));
    }

    @Override
    public int getItemCount() {
        return paysList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;

        public ViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.textViewPays);
        }
    }
}
