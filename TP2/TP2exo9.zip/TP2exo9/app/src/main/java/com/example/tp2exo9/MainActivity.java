package com.example.tp2exo9;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);

        if (savedInstanceState == null) {
            FragmentList fragment = new FragmentList();
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.add(R.id.list, fragment);
            fragmentTransaction.commit();
        }
    }

    public void afficherCarac(Pays pays) {
        FragmentCarac fragment2 = FragmentCarac.newInstance(pays);
        FragmentManager fragmentManager2 = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction2 = fragmentManager2.beginTransaction();
        fragmentTransaction2.replace(R.id.carac, fragment2);
        fragmentTransaction2.addToBackStack(null);
        fragmentTransaction2.commit();
    }
}
