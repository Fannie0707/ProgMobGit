package com.example.tp2exo9;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class FragmentCarac extends Fragment {
    private TextView textViewNom;
    private TextView textViewCapitale;
    private TextView textViewLangue;
    private TextView textViewnbHab;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_carac, container, false);

        textViewNom = v.findViewById(R.id.textViewNom);
        textViewCapitale = v.findViewById(R.id.textViewCapitale);
        textViewLangue = v.findViewById(R.id.textViewLangue);
        textViewnbHab = v.findViewById(R.id.textViewnbHab);

        Bundle args = getArguments();
        if (args != null) {
            String nomPays = args.getString("p_nom");
            String capitalePays = args.getString("p_capitale");
            String languePays = args.getString("p_langue");
            String nbHabPays = args.getString("p_nbHab");

            textViewNom.setText(nomPays);
            textViewCapitale.setText(capitalePays);
            textViewLangue.setText(languePays);
            textViewnbHab.setText(nbHabPays);
        }
        return v;
    }

    public static FragmentCarac newInstance(Pays pays) {
        FragmentCarac fragment = new FragmentCarac();
        Bundle args = new Bundle();

        args.putString("p_nom", pays.getNom());
        args.putString("p_capitale", pays.getCapitale());
        args.putString("p_langue", pays.getLangue());
        args.putString("p_nbHab", pays.getnbHab());

        fragment.setArguments(args);
        return fragment;
    }
}
