package com.example.tp2exo9;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Arrays;
import java.util.List;

public class FragmentList extends Fragment {
    private RecyclerView recyclerView;
    private PaysAdapt paysAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag_list, container, false);
        recyclerView = v.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        List<Pays> paysList = Arrays.asList(
                new Pays("France", "Capitale : Paris", "Langue : Français", "Population : 68,29 millions"),
                new Pays("Allemagne", "Capitale : Berlin", "Langue : Allemand", "Population : 83,24 millions"),
                new Pays("Italie", "Capitale : Rome", "Langue : Italien", "Population : 59,07 millions"),
                new Pays("Espagne", "Capitale : Madrid", "Langue : Espagnol", "Population : 47,42 millions"),
                new Pays("Canada", "Capitale : Ottawa", "Langue : Anglais, Français", "Population : 38,25 millions"),
                new Pays("États-Unis", "Capitale : Washington, D.C.", "Langue : Anglais", "Population : 331,9 millions"),
                new Pays("Brésil", "Capitale : Brasília", "Langue : Portugais", "Population : 215,3 millions"),
                new Pays("Japon", "Capitale : Tokyo", "Langue : Japonais", "Population : 125,7 millions"),
                new Pays("Chine", "Capitale : Pékin", "Langue : Chinois", "Population : 1,41 milliard"),
                new Pays("Inde", "Capitale : New Delhi", "Langue : Hindi, Anglais", "Population : 1,43 milliard"),
                new Pays("Royaume-Uni", "Capitale : Londres", "Langue : Anglais", "Population : 67,33 millions"),
                new Pays("Mexique", "Capitale : Mexico", "Langue : Espagnol", "Population : 126,7 millions"),
                new Pays("Russie", "Capitale : Moscou", "Langue : Russe", "Population : 143,4 millions"),
                new Pays("Australie", "Capitale : Canberra", "Langue : Anglais", "Population : 26,39 millions"),
                new Pays("Afrique du Sud", "Capitale : Pretoria", "Langue : Anglais, Afrikaans, Zoulou", "Population : 59,39 millions")
        );


        paysAdapter = new PaysAdapt(paysList, pays -> {
            if (getActivity() != null) {
                ((MainActivity) getActivity()).afficherCarac(pays);
            }
        });

        recyclerView.setAdapter(paysAdapter);
        return v;
    }
}
