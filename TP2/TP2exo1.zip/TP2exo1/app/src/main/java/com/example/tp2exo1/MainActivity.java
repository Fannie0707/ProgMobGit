package com.example.tp2exo1;

import android.app.Activity;
import static androidx.core.content.ContextCompat.getSystemService;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private ListView liste;
    private ArrayAdapter<String> arrayAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);
        final SensorManager sensorManager = (SensorManager)
                getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> sensorsList =
                sensorManager.getSensorList(Sensor.TYPE_ALL);

        List<String> sensorNames = new ArrayList<>();
        for (Sensor sensor : sensorsList) {
            sensorNames.add(sensor.getName());
        }

        liste = findViewById(R.id.sensors);
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, sensorNames);
        liste.setAdapter(arrayAdapter);
    }
}

