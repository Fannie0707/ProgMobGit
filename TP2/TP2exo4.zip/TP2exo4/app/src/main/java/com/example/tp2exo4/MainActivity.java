package com.example.tp2exo4;

import android.app.Activity;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity implements SensorEventListener {
    SensorManager sensorManager;
    Sensor accelerometer;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }

    @Override
    protected void onPause() {
        sensorManager.unregisterListener(this, accelerometer);
        super.onPause();
    }

    @Override
    protected void onResume() {
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
        super.onResume();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        float x, y;
        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            x = sensorEvent.values[0];
            y = sensorEvent.values[1];

            if (Math.abs(x) > Math.abs(y)) {
                if (x < -0.2) {
                    ((TextView) findViewById(R.id.direction)).setText("Vous allez vers : la gauche");
                } else if (x > 0.2) {
                    ((TextView) findViewById(R.id.direction)).setText("Vous allez vers : la droite");
                }
            }
            else {
                if (y < -0.2) {
                    ((TextView) findViewById(R.id.direction)).setText("Vous allez vers : le bas");
                } else if (y > 0.2) {
                    ((TextView) findViewById(R.id.direction)).setText("Vous allez vers : le haut");
                }
            }

        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }
}
